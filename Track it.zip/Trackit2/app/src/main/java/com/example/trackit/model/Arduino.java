package com.example.trackit.model;

public class Arduino {
    private String codArduino;

    public Arduino(String codArduino) {
        this.codArduino = codArduino;
    }

    public String getCodArduino() {
        return codArduino;
    }

    public void setCodArduino(String codArduino) {
        this.codArduino = codArduino;
    }
}
