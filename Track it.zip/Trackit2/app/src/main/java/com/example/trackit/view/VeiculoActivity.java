package com.example.trackit.view;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.trackit.R;
import com.example.trackit.dao.VeiculoDao;
import com.example.trackit.model.Veiculo;

public class VeiculoActivity extends AppCompatActivity {

    private EditText edtPlaca, edtModelo;
    private Button btnContinuar;
    private VeiculoDao veiculoDao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_veiculo);

        edtPlaca = findViewById(R.id.placa_veiculo);
        edtModelo = findViewById(R.id.modelo_veiculo);
        btnContinuar = findViewById(R.id.btn_continuar_veiculo);

        veiculoDao = new VeiculoDao(this);

        btnContinuar.setOnClickListener(v -> salvarVeiculo());
    }

    private void salvarVeiculo() {
        String placa = edtPlaca.getText().toString().trim();
        String modelo = edtModelo.getText().toString().trim();

        if (placa.isEmpty() || modelo.isEmpty()) {
            Toast.makeText(this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show();
            return;
        }

        Veiculo veiculo = new Veiculo(placa, modelo, 1, null);
        boolean sucesso = veiculoDao.cadastrarVeiculo(veiculo);

        if (sucesso) {
            Toast.makeText(this, "Veículo cadastrado com sucesso!", Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(VeiculoActivity.this, ArduinoActivity.class);
            startActivity(intent);
            finish();
        } else {
            Toast.makeText(this, "Erro ao cadastrar veículo!", Toast.LENGTH_SHORT).show();
        }
    }
}