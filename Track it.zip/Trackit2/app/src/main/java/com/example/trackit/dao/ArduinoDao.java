package com.example.trackit.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.Cursor;

import com.example.trackit.model.Arduino;

public class ArduinoDao {
    private DatabaseHelper dbHelper;

    public ArduinoDao(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    public boolean cadastrarArduino(Arduino arduino) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("codArduino", arduino.getCodArduino());

        long resultado = -1;
        try {
            resultado = db.insert("arduino", null, values);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            db.close();
        }

        return resultado != -1;
    }

    public boolean verificarCodigoExistente(String codArduino) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT codArduino FROM arduino WHERE codArduino = ?", new String[]{codArduino});
        boolean existe = cursor.moveToFirst();
        cursor.close();
        db.close();
        return existe;
    }
}