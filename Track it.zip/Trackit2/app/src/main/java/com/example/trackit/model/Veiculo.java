package com.example.trackit.model;

public class Veiculo {
    private int idVeiculo;
    private String placa;
    private String modelo;
    private int idProprietario;
    private String codArduino;

    public Veiculo(String placa, String modelo, int idProprietario, String codArduino) {
        this.placa = placa;
        this.modelo = modelo;
        this.idProprietario = idProprietario;
        this.codArduino = codArduino;
    }

    public int getIdVeiculo() { return idVeiculo; }
    public String getPlaca() { return placa; }
    public String getModelo() { return modelo; }
    public int getIdProprietario() { return idProprietario; }
    public String getCodArduino() { return codArduino; }
}
