package com.example.trackit.view;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.trackit.R;
import com.example.trackit.dao.ArduinoDao;
import com.example.trackit.model.Arduino;

public class ArduinoActivity extends AppCompatActivity {

    private EditText edtCodArduino;
    private Button btnContinuar;
    private ArduinoDao arduinoDao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_arduino);

        edtCodArduino = findViewById(R.id.cod_arduino);
        btnContinuar = findViewById(R.id.btn_salvar_cod);
        arduinoDao = new ArduinoDao(this);

        btnContinuar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cadastrarArduino();
            }
        });
    }

    private void cadastrarArduino() {
        String codigo = edtCodArduino.getText().toString().trim();

        if (codigo.isEmpty()) {
            Toast.makeText(this, "Informe o código do Arduino!", Toast.LENGTH_SHORT).show();
            return;
        }

        if (arduinoDao.verificarCodigoExistente(codigo)) {
            Toast.makeText(this, "Código já cadastrado!", Toast.LENGTH_SHORT).show();
            return;
        }

        Arduino arduino = new Arduino(codigo);
        boolean sucesso = arduinoDao.cadastrarArduino(arduino);

        if (sucesso) {
            Toast.makeText(this, "Arduino cadastrado com sucesso!", Toast.LENGTH_SHORT).show();

            // Limpar campo
            edtCodArduino.setText("");

            // Redirecionar (exemplo: para tela principal)
            Intent intent = new Intent(ArduinoActivity.this, MainActivity.class);
            startActivity(intent);
            finish();

        } else {
            Toast.makeText(this, "Erro ao cadastrar Arduino!", Toast.LENGTH_SHORT).show();
        }
    }
}