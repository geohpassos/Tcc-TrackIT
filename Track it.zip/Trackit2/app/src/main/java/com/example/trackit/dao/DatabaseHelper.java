package com.example.trackit.dao;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String NOME_BANCO = "trackit.db";
    private static final int VERSAO = 1;

    public static final String TABELA_USUARIOS = "usuarios";
    public static final String COLUNA_ID = "id";
    public static final String COLUNA_NOME = "nome";
    public static final String COLUNA_EMAIL = "email";
    public static final String COLUNA_SENHA = "senha";

    public DatabaseHelper(Context context) {
        super(context, NOME_BANCO, null, VERSAO);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("CREATE TABLE usuarios (" +
                "idUsuario INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "nome TEXT, " +
                "email TEXT UNIQUE, " +
                "senha TEXT)");

        db.execSQL("CREATE TABLE veiculos (" +
                "idVeiculo INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "placa TEXT, " +
                "modelo TEXT, " +
                "idProprietario INTEGER, " +
                "codArduino TEXT, " +
                "FOREIGN KEY (idProprietario) REFERENCES usuarios(idUsuario))");

        db.execSQL("CREATE TABLE arduino (" +
                "codArduino VARCHAR(30) PRIMARY KEY)");

    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABELA_USUARIOS);
        onCreate(db);
    }
}
