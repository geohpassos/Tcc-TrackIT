package com.example.trackit.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

import com.example.trackit.model.Usuario;

public class Dao extends SQLiteOpenHelper {
    public static final String DB_NAME = "trackit.sqlite";
    public static int version = 2;
    SQLiteDatabase db;

    public Dao( Context context) {
        super(context, DB_NAME,null, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String usuario = "CREATE TABLE usuario(id integer primary key autoincrement, nome text,email text UNIQUE, senha text)";
        db.execSQL(usuario);
        Log.d("tabela", "onCreate: Tabela criada "+usuario);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String sql = "DROP TABLE if exists trackit.sqlite";
        db.execSQL(sql);
        onCreate(db);
    }

    public boolean emailExiste(String email){

        Cursor bdemail = db.rawQuery("SELECT id FROM usuario WHERE email = ?",new String[]{email});
        boolean verificarExiste = bdemail.moveToFirst();
        bdemail.close();
        return verificarExiste;
    }

    public boolean senhaExiste(String senha){
        SQLiteDatabase db = null;
        Cursor bdemail = db.rawQuery("SELECT id FROM usuario WHERE senha = ?",new String[]{senha});
        boolean verificarExiste = bdemail.moveToFirst();
        bdemail.close();
        return verificarExiste;
    }
    public boolean cadastrarUsuario(Usuario usuario, StringBuffer db) {
        if (emailExiste(usuario.getEmail())) {
            return false;
        }
        ContentValues usuarios = new ContentValues();
        usuarios.put("nome", usuario.getNome());
        usuarios.put("email", usuario.getEmail());
        usuarios.put("senha", usuario.getSenha());
        return false;
    }
}