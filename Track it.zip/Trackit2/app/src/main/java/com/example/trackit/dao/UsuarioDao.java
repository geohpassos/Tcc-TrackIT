package com.example.trackit.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.trackit.model.Usuario;

public class UsuarioDao {
    private DatabaseHelper dbHelper;

    public UsuarioDao(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    public boolean emailExiste(String email) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT id FROM usuarios WHERE email = ?", new String[]{email});
        boolean existe = cursor.moveToFirst();
        cursor.close();
        db.close();
        return existe;
    }

    public boolean cadastrarUsuario(Usuario usuario) {
        if (emailExiste(usuario.getEmail())) {
            return false;
        }

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues valores = new ContentValues();
        valores.put("nome", usuario.getNome());
        valores.put("email", usuario.getEmail());
        valores.put("senha", usuario.getSenha());

        long resultado = db.insert("usuarios", null, valores);
        db.close();

        return resultado != -1;
    }
}