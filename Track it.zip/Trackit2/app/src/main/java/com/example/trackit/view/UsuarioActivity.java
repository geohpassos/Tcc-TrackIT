package com.example.trackit.view;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.trackit.R;
import com.example.trackit.dao.UsuarioDao;
import com.example.trackit.model.Usuario;

public class UsuarioActivity extends AppCompatActivity {

    private EditText edtNome, edtEmail, edtSenha;
    private Button btnCadastrar;
    private UsuarioDao usuarioDao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_usuario);

        TextView LoginCadastro = findViewById(R.id.login_cadastro);

        LoginCadastro.setOnClickListener(v -> {
            Intent intent = new Intent(UsuarioActivity.this, MainActivity.class);
            startActivity(intent);
        });

        edtNome = findViewById(R.id.nome_cadastro);
        edtEmail = findViewById(R.id.email_cadastro);
        edtSenha = findViewById(R.id.senha_cadastro);
        btnCadastrar = findViewById(R.id.btn_cadastrar);
        usuarioDao = new UsuarioDao(this);
        btnCadastrar.setOnClickListener(v -> salvarUsuario());
    }

    private void salvarUsuario() {
        String nome = edtNome.getText().toString().trim();
        String email = edtEmail.getText().toString().trim();
        String senha = edtSenha.getText().toString().trim();

        if (nome.isEmpty() || email.isEmpty() || senha.isEmpty()) {
            Toast.makeText(this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show();
            return;
        }

        Usuario usuario = new Usuario(nome, email, senha);
        boolean sucesso = usuarioDao.cadastrarUsuario(usuario);

        if (sucesso) {

            Intent intent = new Intent(UsuarioActivity.this, VeiculoActivity.class);
            startActivity(intent);

            Toast.makeText(this, "Usuário cadastrado com sucesso!", Toast.LENGTH_SHORT).show();

            } else {
            Toast.makeText(this, "Erro ao cadastrar usuário!", Toast.LENGTH_SHORT).show();
        }
    }
}