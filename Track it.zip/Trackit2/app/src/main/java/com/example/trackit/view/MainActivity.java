package com.example.trackit.view;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.trackit.R;
import com.example.trackit.dao.Dao;

public class MainActivity extends AppCompatActivity {

    Button login;
    EditText senha, email;
    Dao dao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        TextView cadastroLogin = findViewById(R.id.cadastro_login);

        initComponents();
        login.setOnClickListener(v -> {
            String e = email.getText().toString();
            String s = senha.getText().toString();

           boolean chkEmail = dao.emailExiste(e);
           if (chkEmail) {
               Boolean chkSenha = dao.senhaExiste(s);
               if (chkSenha) {
                   Intent intent = new Intent(this, HomeActivity.class);
               } else {
                   Toast.makeText(this, "Senha incorreta", Toast.LENGTH_SHORT).show();
               }
           } else {
               Toast.makeText(this, "Usuário não existe", Toast.LENGTH_SHORT).show();

           }
        });

        cadastroLogin.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, UsuarioActivity.class);
            startActivity(intent);
        });

        dao = new Dao(getApplicationContext());

    }

    private void initComponents() {
        login = findViewById(R.id.btn_login);
        senha = findViewById(R.id.senha_login);
        email = findViewById(R.id.email_login);
    }
}