package com.example.trackit.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import com.example.trackit.model.Veiculo;

public class VeiculoDao {

    private DatabaseHelper dbHelper;

    public VeiculoDao(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    public boolean cadastrarVeiculo(Veiculo veiculo) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("placa", veiculo.getPlaca());
        values.put("modelo", veiculo.getModelo());
        values.put("idProprietario", veiculo.getIdProprietario());
        values.put("codArduino", veiculo.getCodArduino());

        long resultado = db.insert("veiculos", null, values);
        db.close();

        return resultado != -1;
    }
}